
public class Main {
    public static void main(String[] args) {
        Circulo circulo = new Circulo(8);
        Rectangulo rectangulo = new Rectangulo(6, 8);

        System.out.println("Círculo:");
        System.out.println("Área: " + circulo.calcularArea());
        System.out.println("Perímetro: " + circulo.calcularPerimetro());

        System.out.println("\nRectángulo:");
        System.out.println("Área: " + rectangulo.calcularArea());
        System.out.println("Perímetro: " + rectangulo.calcularPerimetro());
    }
}
